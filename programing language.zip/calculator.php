<?php

$result = "";

class Calculator
{
  function calculate($a, $b, $operator) {
    switch($operator) {
      case 'add':
         return $a + $b;
      case 'subtract':
        return $a - $b;
      case 'multiply':
        return $a * $b;
      case 'divide':
        return $b != 0 ? $a / $b : "Cannot divide by zero";
            
        }   
    }
}

$calculator = new Calculator();

//checks if the operator buttons have beenn clicked  
if(isset($_POST['op'])) { 
    $num1 = $_POST['n1'];
    $num2 = $_POST['n2'];
    $operator = $_POST['op'];

    if(!is_numeric($num1) || !is_numeric($num2)) {
        $result = "Please enter valid numbers!";
    } else {
        $result = $calculator->calculate($num1, $num2, $operator);
    }
}

?>
  
<form method="post">
    <table align="center">
PHP calculator<br> 
<tr>
  <td>1st Number</td>
  <td><input type="text" name="n1"></td>
</tr>

<tr>
   <td>2nd Number</td>
   <td><input type="text" name="n2"></td>
</tr>

<tr>
  <td>Choose operator</td>
<td>
      <button type="submit" name="op" value="add">Addition</button>
      <button type="submit" name="op" value="subtract">Subtraction</button>
      <button type="submit" name="op" value="multiply">Multiplication</button>
      <button type="submit" name="op" value="divide">Division</button>
</td>
   </tr>

  <tr>
   <td><strong><?php echo $result; ?><strong></td>
</tr>
  </table>
  <form action="index.html" method="post">
  <button> Go back </button>
</form>
