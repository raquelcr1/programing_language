// function to generate a random number between min and max
function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

// function to display the generated random number in the HTML
function displayRandomNumber(min, max) {
    const randomNumber = getRandomNumber(min, max);
    document.getElementById("display").textContent = randomNumber;
}


const minNum = 1;
const maxNum = 100;
displayRandomNumber(minNum, maxNum);

// try again button
const tryAgainButton = document.getElementById("tryAgainButton");

// Add event listener to the "Try again" button
tryAgainButton.addEventListener("click", function() {
    displayRandomNumber(minNum, maxNum);
});