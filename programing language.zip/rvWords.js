//code to write words backwards

function printBackwards(word) {
  var reversedWord = "";
  for (var i = word.length - 1; i >= 0; i--) {
      reversedWord += word[i];
  }
  var outputElement = document.getElementById("output");
    outputElement.innerHTML = "The word " + word + " backwards is: " + reversedWord;

}