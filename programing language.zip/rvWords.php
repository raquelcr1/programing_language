<html>
  <body>
  <form method="post">
    Enter a word: <input type="text" name="word"><br>
    <input type="submit" value="Submit">
  </form>

<?php

// Function to print a word backwards
  function printWordBackwards($word) {
    $length = strlen($word);
      for ($i = $length - 1; $i >= 0; $i--) {
         echo $word[$i];
      }
  }

// Check if form is submitted
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $word = $_POST["word"];
 // Print the original word and its reverse
  echo "<br>Original word: " . $word . "<br>";
  echo "Word printed backwards: ";
    printWordBackwards($word);
  }
?>
</body>
</html>
