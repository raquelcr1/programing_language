<?php
// getRandomNumber.php
function getRandomNumber($min, $max) {
    return rand($min, $max);
}

// Generate a random number between 1 and 100
$randomNumber = getRandomNumber(1, 100);

// Output the random number
echo $randomNumber;
?>
